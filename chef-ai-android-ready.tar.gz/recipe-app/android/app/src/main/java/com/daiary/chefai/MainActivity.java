package com.daiary.chefai;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
